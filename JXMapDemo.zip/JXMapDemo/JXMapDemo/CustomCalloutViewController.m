//
//  CustomCalloutViewController.m
//  MapKitDemo
//
//  Created by JackXu on 15/6/22.
//  Copyright (c) 2015年 BFMobile. All rights reserved.
//

#import "CustomCalloutViewController.h"
@interface CustomCalloutViewController ()

@end

@implementation CustomCalloutViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
