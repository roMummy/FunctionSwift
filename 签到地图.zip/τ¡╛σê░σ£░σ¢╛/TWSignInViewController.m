//
//  TWSignInViewController.m
//  SellSignName
//
//  Created by TW on 2017/9/19.
//  Copyright © 2017年 代俊. All rights reserved.
//

#import "TWSignInViewController.h"
#import <MapKit/MapKit.h>
#import "ASLocationManager.h"
#import "TWCustomAnnotationVIew.h"

@interface TWSignInViewController ()<MKMapViewDelegate>

@property (nonatomic, strong) MKMapView * mapView;
@property (nonatomic, strong) UIButton * localizeButton;//定位按钮
@property (nonatomic, strong) UIButton * signInButton;//签到按钮

@end

@implementation TWSignInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"签到";
    [self setupUI];
    //添加大头针
    [self addBigPin];
    // Do any additional setup after loading the view.
}

- (void)setupUI {
    [self.view addSubview:self.mapView];
    [self.view addSubview:self.localizeButton];
    [self.view addSubview:self.signInButton];
    
    [self.mapView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
    [self.localizeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(10);
        make.bottom.equalTo(self.view).offset(-80);
    }];
    [self.signInButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view).offset(-22);
        make.left.mas_equalTo(42);
        make.right.mas_equalTo(-42);
        make.height.mas_equalTo(40);
    }];
    
}
- (void)addBigPin {
    MKPointAnnotation * annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:CLLocationCoordinate2DMake(30.50, 104.01)];
    [annotation setTitle:@"123"];
    [annotation setSubtitle:@"123123"];
    [self.mapView addAnnotation:annotation];
}
#pragma mark - MKMapViewDelegate

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
//    self.mapView.centerCoordinate = userLocation.location.coordinate;
}
//地图区域发生变化
- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    
}
//地图加载完之后会调用这个方法
- (void)mapViewDidFinishLoadingMap:(MKMapView *)mapView {
    self.signInButton.userInteractionEnabled = YES;
}

//设置大头针
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    if ([annotation isKindOfClass:[MKPointAnnotation class]]) {
//        MKAnnotationView * view = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MKAnnotationView"];
//        view.image = [UIImage imageNamed:@"Qiandao_map_touxiang_bg"];
//        view.canShowCallout = YES;
        
        TWCustomAnnotationVIew *annotationView = (TWCustomAnnotationVIew *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"MyCustomAnnotationView"];
        if (!annotationView) {
            annotationView = [[TWCustomAnnotationVIew alloc] initWithAnnotation:annotation reuseIdentifier:@"MyCustomAnnotationView"];
            annotationView.image = [UIImage imageNamed:@"Qiandao_map_touxiang_bg"];
            annotationView.calloutOffset = CGPointMake(100, -100);
        }
        
        return annotationView;
        
    }
    return nil;
}
#pragma mark - 点击
- (void)localizeClick {
    NSLog(@"定位");
//    self.mapView.centerCoordinate = [ASLocationManager sharedInstance].coordinate2D;
    self.mapView.centerCoordinate = CLLocationCoordinate2DMake(30.50, 104.01);
}
- (void)signInClick {
    NSLog(@"签到");
}

#pragma mark - lazy
- (MKMapView *)mapView {
    if (!_mapView) {
        _mapView = [[MKMapView alloc] init];
        _mapView.userTrackingMode = MKUserTrackingModeFollowWithHeading;
        _mapView.rotateEnabled = NO;
        _mapView.showsCompass = NO;
        _mapView.delegate = self;
        MKCoordinateSpan span = MKCoordinateSpanMake(0.05, 0.01);
        MKCoordinateRegion region = MKCoordinateRegionMake([ASLocationManager sharedInstance].coordinate2D, span);
        _mapView.region = region;
    }
    return _mapView;
}
- (UIButton *)localizeButton {
    if (!_localizeButton) {
        _localizeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_localizeButton setImage:[UIImage imageNamed:@"Qiandao_map_dingwei"] forState:UIControlStateNormal];
        [_localizeButton addTarget:self action:@selector(localizeClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _localizeButton;
}
- (UIButton *)signInButton {
    if (!_signInButton) {
        _signInButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signInButton setBackgroundColor:[ASAppColorsManager colorBGOrange]];
        [_signInButton setTitle:@"签到" forState:UIControlStateNormal];
        [_signInButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_signInButton addTarget:self action:@selector(signInClick) forControlEvents:UIControlEventTouchUpInside];
        _signInButton.layer.cornerRadius = 20.0f;
        _signInButton.layer.masksToBounds = YES;
        _signInButton.userInteractionEnabled = NO;
    }
    return _signInButton;
}
@end
