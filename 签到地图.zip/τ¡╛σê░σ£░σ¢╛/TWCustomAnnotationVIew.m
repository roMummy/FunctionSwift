//
//  TWCustomAnnotationVIew.m
//  SellSignName
//
//  Created by TW on 2017/9/19.
//  Copyright © 2017年 代俊. All rights reserved.
//

#import "TWCustomAnnotationVIew.h"

@interface TWCustomAnnotationVIew ()
@property (nonatomic, strong) UILabel * nameLabel;
@property (nonatomic, strong) UILabel * timeLabel;
@property (nonatomic, strong) UILabel * contentLabel;
@property (nonatomic, strong) UIImageView * addressImageView;
@property (nonatomic, strong) UILabel * addressLabel;

@end
@implementation TWCustomAnnotationVIew

- (instancetype)initWithAnnotation:(id<MKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.calloutOffset = CGPointMake(100, 100);//设置偏移量
        self.frame = CGRectMake(0, 0, 200, 100);
        self.canShowCallout = YES;
        [self setupUI];
    }
    return self;
}

- (void)setupUI {
    [self addSubview:self.nameLabel];
    [self addSubview:self.timeLabel];
    [self addSubview:self.contentLabel];
    [self addSubview:self.addressImageView];
    [self addSubview:self.addressLabel];
    
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(9);
        make.left.mas_equalTo(10);
    }];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.nameLabel);
        make.left.equalTo(self.nameLabel.mas_right).offset(5);
    }];
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.nameLabel.mas_bottom).offset(5);
        make.left.mas_equalTo(10);
    }];
    [self.addressImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.mas_bottom).offset(9);
        make.left.mas_equalTo(10);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    [self.addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.addressImageView);
        make.left.equalTo(self.addressImageView.mas_right).offset(5);
    }];
    
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *hitView = [super hitTest:point withEvent:event];
    if (hitView == nil && self.selected) {
        CGPoint pointInAnnotationView = [self.superview convertPoint:point toView:self];
        UIView *calloutView = self;
        hitView = [calloutView hitTest:pointInAnnotationView withEvent:event];
    }
    return hitView;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:YES];
    
    // Get the custom callout view.
    UIView *calloutView = self;
    if (selected) {
//        self.calloutViewController.maintitle.text = self.myCustomAnnotation.maintitle;
//        self.calloutViewController.secondtitle.text = self.myCustomAnnotation.secondtitle;
        
        CGRect annotationViewBounds = self.bounds;
        CGRect calloutViewFrame = calloutView.frame;
        if (calloutViewFrame.origin.x==annotationViewBounds.origin.x) {
            // Center the callout view above and to the right of the annotation view.
            calloutViewFrame.origin.x  -= (calloutViewFrame.size.width - annotationViewBounds.size.width) * 0.5;
            calloutViewFrame.origin.y -= (calloutViewFrame.size.height);
            calloutView.frame = calloutViewFrame;
        }
        
        [self addSubview:calloutView];
    } else {
        [calloutView removeFromSuperview];
    }
}
#pragma mark - lazy

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.text = @"杨丽";
        _nameLabel.font = [UIFont boldSystemFontOfSize:15];
        _nameLabel.textColor = [ASAppColorsManager colorDarkText];
    }
    return _nameLabel;
}

- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.text = @"2017.08.30";
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.textColor = [ASAppColorsManager colorGrayText];
    }
    return _timeLabel;
}

- (UILabel *)contentLabel {
    if (!_contentLabel) {
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.text = @"今天天气不错，收获不错！";
        _contentLabel.font = [UIFont systemFontOfSize:12];
        _contentLabel.textColor = [ASAppColorsManager colorGrayText];
    }
    return _contentLabel;
}

- (UIImageView *)addressImageView {
    if (!_addressImageView) {
        _addressImageView = [[UIImageView alloc] init];
        _addressImageView.image = [UIImage imageNamed:@"Xiaoshouqiandao_dinwei"];
    }
    return _addressImageView;
}

- (UILabel *)addressLabel {
    if (!_addressLabel) {
        _addressLabel = [[UILabel alloc] init];
        _addressLabel.text = @"环球中心";
        _addressLabel.font = [UIFont systemFontOfSize:13.0f];
        _addressLabel.textColor = [ASAppColorsManager colorDarkText];
    }
    return _addressLabel;
}
@end
